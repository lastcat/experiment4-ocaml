(* ex7_2 incr function *)
let x = ref 3;;
let incr x = x := !x+1;;
(* incr x;; !x OUTPUT:4*)
